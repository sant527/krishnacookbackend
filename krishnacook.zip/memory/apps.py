from django.apps import AppConfig


class MemoryConfig(AppConfig):
    name = 'memory'
