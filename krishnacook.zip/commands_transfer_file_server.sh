cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/views.py /mnt/sshfs/dev-cook/src/ingredients/views.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/urls.py /mnt/sshfs/dev-cook/src/ingredients/urls.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/tests.py /mnt/sshfs/dev-cook/src/ingredients/tests.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/models.py /mnt/sshfs/dev-cook/src/ingredients/models.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/forms.py /mnt/sshfs/dev-cook/src/ingredients/forms.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/apps.py /mnt/sshfs/dev-cook/src/ingredients/apps.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/admin.py /mnt/sshfs/dev-cook/src/ingredients/admin.py

cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/krishnacook/settings.py /mnt/sshfs/dev-cook/src/krishnacook/settings.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/krishnacook/urls.py /mnt/sshfs/dev-cook/src/krishnacook/urls.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/krishnacook/wsgi.py /mnt/sshfs/dev-cook/src/krishnacook/wsgi.py

cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/menu/admin.py /mnt/sshfs/dev-cook/src/menu/admin.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/menu/apps.py /mnt/sshfs/dev-cook/src/menu/apps.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/menu/forms.py /mnt/sshfs/dev-cook/src/menu/forms.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/menu/models.py /mnt/sshfs/dev-cook/src/menu/models.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/menu/tests.py /mnt/sshfs/dev-cook/src/menu/tests.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/menu/urls.py /mnt/sshfs/dev-cook/src/menu/urls.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/menu/views.py /mnt/sshfs/dev-cook/src/menu/views.py

cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/recipes/admin.py /mnt/sshfs/dev-cook/src/recipes/admin.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/recipes/apps.py /mnt/sshfs/dev-cook/src/recipes/apps.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/recipes/forms.py /mnt/sshfs/dev-cook/src/recipes/forms.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/recipes/models.py /mnt/sshfs/dev-cook/src/recipes/models.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/recipes/tests.py /mnt/sshfs/dev-cook/src/recipes/tests.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/recipes/urls.py /mnt/sshfs/dev-cook/src/recipes/urls.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/recipes/views.py /mnt/sshfs/dev-cook/src/recipes/views.py


cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/single_measurements/admin.py /mnt/sshfs/dev-cook/src/single_measurements/admin.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/single_measurements/apps.py /mnt/sshfs/dev-cook/src/single_measurements/apps.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/single_measurements/forms.py /mnt/sshfs/dev-cook/src/single_measurements/forms.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/single_measurements/models.py /mnt/sshfs/dev-cook/src/single_measurements/models.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/single_measurements/tests.py /mnt/sshfs/dev-cook/src/single_measurements/tests.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/single_measurements/urls.py /mnt/sshfs/dev-cook/src/single_measurements/urls.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/single_measurements/views.py /mnt/sshfs/dev-cook/src/single_measurements/views.py




cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/tags/admin.py /mnt/sshfs/dev-cook/src/tags/admin.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/tags/apps.py /mnt/sshfs/dev-cook/src/tags/apps.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/tags/forms.py /mnt/sshfs/dev-cook/src/tags/forms.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/tags/models.py /mnt/sshfs/dev-cook/src/tags/models.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/tags/tests.py /mnt/sshfs/dev-cook/src/tags/tests.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/tags/urls.py /mnt/sshfs/dev-cook/src/tags/urls.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/tags/views.py /mnt/sshfs/dev-cook/src/tags/views.py

cp -v -R /home/web_dev/exclude/.virtualenvs/krishnacook/src/templates /mnt/sshfs/dev-cook/src

#cp -v -R /home/web_dev/exclude/.virtualenvs/krishnacook/src/static /mnt/sshfs/dev-cook/src

cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/static/css/main.css /mnt/sshfs/dev-cook/static_cdn/css/

cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/typeofingredient/admin.py /mnt/sshfs/dev-cook/src/typeofingredient/admin.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/typeofingredient/apps.py /mnt/sshfs/dev-cook/src/typeofingredient/apps.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/typeofingredient/forms.py /mnt/sshfs/dev-cook/src/typeofingredient/forms.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/typeofingredient/models.py /mnt/sshfs/dev-cook/src/typeofingredient/models.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/typeofingredient/tests.py /mnt/sshfs/dev-cook/src/typeofingredient/tests.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/typeofingredient/urls.py /mnt/sshfs/dev-cook/src/typeofingredient/urls.py
cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/typeofingredient/views.py /mnt/sshfs/dev-cook/src/typeofingredient/views.py


cp -v /home/web_dev/exclude/.virtualenvs/krishnacook/src/ingredients/templatetags/ingredient_quantity.py /mnt/sshfs/dev-cook/src/ingredients/templatetags/ingredient_quantity.py


echo "********************END*****************************************"