from django.apps import AppConfig


class TypeofingredientConfig(AppConfig):
    name = 'typeofingredient'
