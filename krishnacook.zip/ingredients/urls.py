from django.conf.urls import url
from django.contrib import admin
from .views import ingredient_list,ingredient_update,ingredient_delete,ingredient_confirm,ingredient_formset_update,ingredient_formset_create


urlpatterns = [
	url(r'^$', ingredient_list, name='list'),
	url(r'^edit/$', ingredient_formset_update , name='formsetedit'),
	url(r'^create/$', ingredient_formset_create , name='formsetcreate'),
	# url(r'^create/$', ingredient_create),
	# url(r'^(?P<slug>[\w-]+)/$', ingredient_detail, name='detail'),
	url(r'^(?P<slug>[\w-]+)/edit/$', ingredient_update, name='update'),
	url(r'^(?P<slug>[\w-]+)/delete/$', ingredient_delete, name='delete'),
	url(r'^(?P<slug>[\w-]+)/confirm/$', ingredient_confirm, name='confirm'),

]