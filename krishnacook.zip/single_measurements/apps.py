from django.apps import AppConfig


class SingleMeasurementsConfig(AppConfig):
    name = 'single_measurements'
