rm -rf /home/simha/.config/sublime-text-3/Local/*
subl3 -n -a "/home/web_dev/exclude/.virtualenvs/krishnacook/src"