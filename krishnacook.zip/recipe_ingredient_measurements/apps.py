from django.apps import AppConfig


class RecipeIngredientMesesurementsConfig(AppConfig):
    name = 'recipe_ingredient_mesesurements'
